#
# Cookbook:: apache
# Recipe:: default
#
# Copyright:: 2020, The Authors, All Rights Reserved.
include_recipe 'apache::server'
include_recipe 'apache::hello'
include_recipe 'apache::setup'
