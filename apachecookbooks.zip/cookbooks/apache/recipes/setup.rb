package 'tree' do
action :install
end

package 'ntp'

file '/etc/motd' do
content 'this is the propert of IBM'
end

service 'ntpd' do
action [:enable, :start]
end
