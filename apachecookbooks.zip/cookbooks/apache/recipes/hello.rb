file '/home/hello.txt' do
content 'Hello IBM'
end
